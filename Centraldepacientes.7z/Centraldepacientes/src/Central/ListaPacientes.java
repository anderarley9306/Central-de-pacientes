package Central;

public class ListaPacientes {
    private Nodo cabeza; 

   
    private class Nodo {
        Paciente paciente;
        Nodo siguiente;

        Nodo(Paciente paciente) {
            this.paciente = paciente;
            this.siguiente = null;
        }
    }

    
    public ListaPacientes() {
        this.cabeza = null;
    }

    
    public boolean agregarPaciente(Paciente paciente) {
        if (buscarPaciente(paciente.getId()) != null) {
            return false; 
        }

        Nodo nuevo = new Nodo(paciente);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
        return true;
    }

  
    public Paciente buscarPaciente(int id) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.paciente.getId() == id) {
                return actual.paciente;
            }
            actual = actual.siguiente;
        }
        return null;
    }

 
    public boolean eliminarPaciente(int id) {
        if (cabeza == null) return false;

        if (cabeza.paciente.getId() == id) {
            cabeza = cabeza.siguiente;
            return true;
        }

        Nodo actual = cabeza;
        while (actual.siguiente != null && actual.siguiente.paciente.getId() != id) {
            actual = actual.siguiente;
        }

        if (actual.siguiente == null) return false;

        actual.siguiente = actual.siguiente.siguiente;
        return true;
    }

    
    public String mostrarPacientes() {
        if (cabeza == null) return "No hay pacientes registrados.";

        StringBuilder sb = new StringBuilder();
        Nodo actual = cabeza;
        while (actual != null) {
            sb.append("ID: ").append(actual.paciente.getId())
              .append(", Nombre: ").append(actual.paciente.getNombre())
              .append(", Edad: ").append(actual.paciente.getEdad())
              .append(", Clínica: ").append(actual.paciente.getClinica())
              .append("\n");
            actual = actual.siguiente;
        }
        return sb.toString();
    }
}
