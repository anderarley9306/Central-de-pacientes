package Central;

public class ArbolPacientes {
    class Nodo {
        Paciente paciente;
        Nodo izquierda, derecha;

        public Nodo(Paciente paciente) {
            this.paciente = paciente;
            izquierda = derecha = null;
        }
    }

    Nodo raiz;

    public ArbolPacientes() {
        raiz = null;
    }

   
    public void insertar(Paciente paciente) {
        raiz = insertarRec(raiz, paciente);
    }

    private Nodo insertarRec(Nodo raiz, Paciente paciente) {
        if (raiz == null) {
            raiz = new Nodo(paciente);
            return raiz;
        }
        if (paciente.getId() < raiz.paciente.getId()) {
            raiz.izquierda = insertarRec(raiz.izquierda, paciente);
        } else if (paciente.getId() > raiz.paciente.getId()) {
            raiz.derecha = insertarRec(raiz.derecha, paciente);
        }
        return raiz;
    }

  
    public Paciente buscar(int id) {
        return buscarRec(raiz, id);
    }

    private Paciente buscarRec(Nodo raiz, int id) {
        if (raiz == null || raiz.paciente.getId() == id) {
            return (raiz != null) ? raiz.paciente : null;
        }
        if (id < raiz.paciente.getId()) {
            return buscarRec(raiz.izquierda, id);
        }
        return buscarRec(raiz.derecha, id);
    }

   
    public String mostrarPacientes() {
        StringBuilder sb = new StringBuilder();
        mostrarInOrden(raiz, sb);
        return sb.toString();
    }

    private void mostrarInOrden(Nodo raiz, StringBuilder sb) {
        if (raiz != null) {
            mostrarInOrden(raiz.izquierda, sb);
            sb.append("ID: ").append(raiz.paciente.getId())
              .append(", Nombre: ").append(raiz.paciente.getNombre())
              .append(", Edad: ").append(raiz.paciente.getEdad())
              .append(", Clínica: ").append(raiz.paciente.getClinica())
              .append("\n");
            mostrarInOrden(raiz.derecha, sb);
        }
    }

    
    public void eliminar(int id) {
        raiz = eliminarRec(raiz, id);
    }

    private Nodo eliminarRec(Nodo raiz, int id) {
        if (raiz == null) {
            return raiz;
        }

        if (id < raiz.paciente.getId()) {
            raiz.izquierda = eliminarRec(raiz.izquierda, id);
        } else if (id > raiz.paciente.getId()) {
            raiz.derecha = eliminarRec(raiz.derecha, id);
        } else {
            
            if (raiz.izquierda == null) {
                return raiz.derecha;
            } else if (raiz.derecha == null) {
                return raiz.izquierda;
            }

            
            raiz.paciente = minValor(raiz.derecha);
            raiz.derecha = eliminarRec(raiz.derecha, raiz.paciente.getId());
        }
        return raiz;
    }

    private Paciente minValor(Nodo raiz) {
        Paciente min = raiz.paciente;
        while (raiz.izquierda != null) {
            min = raiz.izquierda.paciente;
            raiz = raiz.izquierda;
        }
        return min;
    }
}
