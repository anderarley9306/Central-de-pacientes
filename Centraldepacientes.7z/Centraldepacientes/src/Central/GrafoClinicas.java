package Central;


import java.util.*;

public class GrafoClinicas {
    private final Map<String, List<Conexion>> grafo = new HashMap<>();

    public void agregarClinica(String nombre) {
        grafo.putIfAbsent(nombre, new ArrayList<>());
    }

    public void conectarClinicas(String origen, String destino, int distancia) {
        grafo.get(origen).add(new Conexion(destino, distancia));
        grafo.get(destino).add(new Conexion(origen, distancia));
    }

    public Map<String, Integer> dijkstra(String inicio) {
        Map<String, Integer> distancias = new HashMap<>();
        for (String nodo : grafo.keySet()) distancias.put(nodo, Integer.MAX_VALUE);
        distancias.put(inicio, 0);

        PriorityQueue<Conexion> pq = new PriorityQueue<>(Comparator.comparingInt(c -> c.distancia));
        pq.add(new Conexion(inicio, 0));

        while (!pq.isEmpty()) {
            Conexion actual = pq.poll();
            for (Conexion vecino : grafo.get(actual.destino)) {
                int nuevaDist = distancias.get(actual.destino) + vecino.distancia;
                if (nuevaDist < distancias.get(vecino.destino)) {
                    distancias.put(vecino.destino, nuevaDist);
                    pq.add(new Conexion(vecino.destino, nuevaDist));
                }
            }
        }
        return distancias;
    }
}
