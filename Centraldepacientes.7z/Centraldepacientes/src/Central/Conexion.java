package Central;

public class Conexion {
    public String destino;
    public int distancia;

    public Conexion(String destino, int distancia) {
        this.destino = destino;
        this.distancia = distancia;
    }
}
