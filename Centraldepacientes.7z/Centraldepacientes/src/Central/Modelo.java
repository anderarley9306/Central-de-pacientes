package Central;

public class Modelo {
    private ListaPacientes lista;

    public Modelo() {
        lista = new ListaPacientes();
    }

 
    public boolean agregarPaciente(int id, String nombre, int edad, String clinica) {
        Paciente p = new Paciente(id, nombre, edad, clinica);
        return lista.agregarPaciente(p);
    }

    
    public Paciente buscarPaciente(int id) {
        return lista.buscarPaciente(id); 
    }

    
    public boolean eliminarPaciente(int id) {
        return lista.eliminarPaciente(id);
    }

    
    public String mostrarPacientes() {
        return lista.mostrarPacientes();
    }
}
