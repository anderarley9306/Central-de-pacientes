package Central;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;





@SuppressWarnings("unused")
public class Vista extends JFrame {

	private static final long serialVersionUID = 1L;
	public JPanel contentPane;
	public JTextField txtId;
	public JTextField txtNombre;
	public JTextField txtEdad;
	public JTextField txtClinica;
	public JTextArea textArea;
	public JButton btnAgregar, btnBuscar, btnEliminar, btnMostrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista frame = new Vista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Vista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 602, 497);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Central De Pacientes");
		lblNewLabel.setBounds(193, 22, 155, 36);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setBounds(76, 92, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Nombre");
		lblNewLabel_2.setBounds(76, 117, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Edad");
		lblNewLabel_3.setBounds(76, 142, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Clinica");
		lblNewLabel_4.setBounds(76, 167, 46, 14);
		contentPane.add(lblNewLabel_4);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.setBounds(78, 209, 89, 23);
		contentPane.add(btnAgregar);
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(177, 209, 89, 23);
		contentPane.add(btnBuscar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(276, 209, 89, 23);
		contentPane.add(btnEliminar);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.setBounds(375, 209, 89, 23);
		contentPane.add(btnMostrar);
		
		txtId = new JTextField();
		txtId.setBounds(224, 89, 86, 20);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(224, 114, 86, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtEdad = new JTextField();
		txtEdad.setBounds(224, 139, 86, 20);
		contentPane.add(txtEdad);
		txtEdad.setColumns(10);
		
		txtClinica = new JTextField();
		txtClinica.setBounds(224, 164, 86, 20);
		contentPane.add(txtClinica);
		txtClinica.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setBounds(45, 276, 457, 148);
		contentPane.add(textArea);

	}
}
