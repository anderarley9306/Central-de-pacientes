package Central;

public class Main {
    public static void main(String[] args) {
       
        Vista vista = new Vista();

       
        Modelo modelo = new Modelo();

       
        Controlador controlador = new Controlador(vista, modelo);

        
        vista.setTitle("Central de Pacientes");
        vista.setLocationRelativeTo(null); 
        vista.setVisible(true);
    }
}
