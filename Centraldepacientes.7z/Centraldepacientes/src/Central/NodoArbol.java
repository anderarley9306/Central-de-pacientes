package Central;

public class NodoArbol {
    public Paciente paciente;
    public NodoArbol izq, der;

    public NodoArbol(Paciente paciente) {
        this.paciente = paciente;
    }
}
