package Central;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador {
    private Vista vista;
    private Modelo modelo;

    public Controlador(Vista vista, Modelo modelo) {
        this.vista = vista;
        this.modelo = modelo;
        initControl();
    }

    private void initControl() {
        vista.btnAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarPaciente();
            }
        });

        vista.btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarPaciente();
            }
        });

        vista.btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarPaciente();
            }
        });

        vista.btnMostrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarPacientes();
            }
        });
    }

    private void agregarPaciente() {
        try {
            int id = Integer.parseInt(vista.txtId.getText());
            String nombre = vista.txtNombre.getText();
            int edad = Integer.parseInt(vista.txtEdad.getText());
            String clinica = vista.txtClinica.getText();

            
            if (modelo.buscarPaciente(id) != null) {
                JOptionPane.showMessageDialog(vista, "El ID ya existe. No se puede agregar.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean agregado = modelo.agregarPaciente(id, nombre, edad, clinica); 
            if (agregado) {
                JOptionPane.showMessageDialog(vista, "Paciente agregado correctamente");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo agregar el paciente");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "ID y Edad deben ser números", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarPaciente() {
        try {
            int id = Integer.parseInt(vista.txtId.getText());
            Paciente paciente = modelo.buscarPaciente(id);
            if (paciente != null) {
                vista.textArea.setText("ID: " + paciente.getId() + "\nNombre: " + paciente.getNombre() +
                        "\nEdad: " + paciente.getEdad() + "\nClinica: " + paciente.getClinica());
            } else {
                JOptionPane.showMessageDialog(vista, "Paciente no encontrado");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, " ID debe ser un número", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarPaciente() {
        try {
            int id = Integer.parseInt(vista.txtId.getText());
            boolean eliminado = modelo.eliminarPaciente(id);
            if (eliminado) {
                JOptionPane.showMessageDialog(vista, "Paciente eliminado correctamente");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(vista, "No se encontró el paciente");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "ID debe ser un número", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarPacientes() {
        vista.textArea.setText(modelo.mostrarPacientes());
    }

    private void limpiarCampos() {
        vista.txtId.setText("");
        vista.txtNombre.setText("");
        vista.txtEdad.setText("");
        vista.txtClinica.setText("");
    }
}
