module Centraldepacientes {
	requires java.desktop;
}